package behavioral_patterns.command;

public class Client {
	public static void main(String args[]){
		FunctionButton fb=new FunctionButton();
		Command com=new ExitCommand();
		fb.setCommand(com);
		fb.click();
	}
}
