package behavioral_patterns.command;

public abstract class Command {
	public abstract void execute();
}
