package behavioral_patterns.command;

public class HelpCommand extends Command{
	private DisplayHelpClass hcobj;
	public HelpCommand(){
		hcobj=new DisplayHelpClass();
	}
	@Override
	public void execute() {
		hcobj.display();
	}

}
