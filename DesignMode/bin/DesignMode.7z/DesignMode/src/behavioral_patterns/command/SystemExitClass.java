package behavioral_patterns.command;

public class SystemExitClass {
	public void exit(){
		System.out.println("�˳�ϵͳ��");
	}
}
