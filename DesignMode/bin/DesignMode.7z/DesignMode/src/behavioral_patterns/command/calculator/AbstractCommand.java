package behavioral_patterns.command.calculator;

public abstract class AbstractCommand {
	public abstract int execute(int value);
	public abstract int undo();
}
