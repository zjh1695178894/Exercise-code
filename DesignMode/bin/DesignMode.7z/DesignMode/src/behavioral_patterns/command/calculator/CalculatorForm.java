package behavioral_patterns.command.calculator;

public class CalculatorForm {
	private AbstractCommand command;
	public void setCommand(AbstractCommand command){
		this.command=command;
	}
	
	public void computer(int value){
		int i=command.execute(value);
		System.out.println("��������"+i);
		
	}
	public void undo(){
		int i=command.undo();
		System.out.println("����������"+i);
	}
}
