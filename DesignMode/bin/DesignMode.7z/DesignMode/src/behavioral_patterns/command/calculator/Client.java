package behavioral_patterns.command.calculator;

public class Client {
	public static void main(String args[]){
	CalculatorForm cf=new CalculatorForm();
	AbstractCommand command=new AddCommand();
	cf.setCommand(command);
	
	cf.computer(10);
	cf.computer(15);
	cf.computer(20);
	cf.undo();
	}
	
}
