package behavioral_patterns.cor;

public class Client {
	public static void main(String args[]){
		Approver a=new Director("A");
		Approver b=new VicePresident("B");
		Approver c=new President("C");
		Approver d=new Congress("D");
		
		a.setSuccessor(b);
		b.setSuccessor(c);
		c.setSuccessor(d);
		
		PurchaseRequest pr1=new PurchaseRequest(45000,10001,"�Ƽ�1");
		PurchaseRequest pr2=new PurchaseRequest(65000,10002,"�Ƽ�2");
		PurchaseRequest pr3=new PurchaseRequest(85000,10003,"�Ƽ�3");
		PurchaseRequest pr4=new PurchaseRequest(1235000,10004,"�Ƽ�4");
		a.processRequest(pr1);
		a.processRequest(pr2);
		a.processRequest(pr3);
		a.processRequest(pr4);
	}
}
