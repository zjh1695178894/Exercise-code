package behavioral_patterns.cor;

public class Director extends Approver{

	public Director(String name) {
		super(name);
	}

	@Override
	public void processRequest(PurchaseRequest request) {
		if(request.getAmount()<50000){
			System.out.println("����"+this.name+"�����ɹ���"+request.getNumber()+",���"+request.getAmount()+
					"Ԫ,�ɹ�Ŀ��"+request.getPurpose());
		}else{
			this.successor.processRequest(request);
		}
	}

}
