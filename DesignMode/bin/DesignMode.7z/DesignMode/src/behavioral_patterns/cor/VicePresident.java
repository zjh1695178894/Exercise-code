package behavioral_patterns.cor;

public class VicePresident extends Approver{

	public VicePresident(String name) {
		super(name);
	}

	@Override
	public void processRequest(PurchaseRequest request) {
		if(request.getAmount()<100000){
			System.out.println("�����³�"+this.name+"�����ɹ���"+request.getNumber()+",���"+request.getAmount()+
					"Ԫ,�ɹ�Ŀ��"+request.getPurpose());
		}else{
			this.successor.processRequest(request);
		}
	}

}
