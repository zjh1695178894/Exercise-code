package behavioral_patterns.interpreter;

public abstract class AbstractNode {
	public abstract String interpreter();
}
