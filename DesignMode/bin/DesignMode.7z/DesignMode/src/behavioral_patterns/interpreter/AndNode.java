package behavioral_patterns.interpreter;

public class AndNode extends AbstractNode{
	private AbstractNode left;
	private AbstractNode right;
	public AndNode(AbstractNode left,AbstractNode right){
		this.left=left;
		this.right=right;
	}
	@Override
	public String interpreter() {
		return left.interpreter()+"��"+right.interpreter();
	}

}
