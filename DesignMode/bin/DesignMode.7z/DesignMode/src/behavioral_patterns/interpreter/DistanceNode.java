package behavioral_patterns.interpreter;

public class DistanceNode extends AbstractNode{
	private String distance;
	public DistanceNode(String distance){
		this.distance=distance;
	}

	@Override
	public String interpreter() {
		return this.distance;
	}

}
