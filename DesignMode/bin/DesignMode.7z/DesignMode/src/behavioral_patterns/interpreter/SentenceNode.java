package behavioral_patterns.interpreter;

public class SentenceNode extends AbstractNode{
	private AbstractNode direction;
	private AbstractNode action;
	private AbstractNode distance;
	
	public SentenceNode(AbstractNode direction,AbstractNode action,AbstractNode distance){
		this.direction=direction;
		this.action=action;
		this.distance=distance;
	}

	@Override
	public String interpreter() {
		// TODO Auto-generated method stub
		return direction.interpreter()+action.interpreter()+distance.interpreter();
	}
}
