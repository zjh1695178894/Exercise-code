package behavioral_patterns.iterator;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractObjectList {
	protected List<Object> objects=new ArrayList<>();
	
	public AbstractObjectList(List<Object> objects){
		this.objects=objects;
	}
	
	public void addList(Object obj){
		this.objects.add(obj);
	}
	public void removeList(Object obj){
		this.objects.remove(obj);
	}
	public List<Object> getList(){
		return this.objects;
	}
	
	public abstract AbstractIterator createIterator();
}
