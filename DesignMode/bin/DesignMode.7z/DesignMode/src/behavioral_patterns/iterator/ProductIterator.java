package behavioral_patterns.iterator;

import java.util.List;

public class ProductIterator implements AbstractIterator {
	private List<Object> products;
	private int cursor1;
	private int cursor2;
	public ProductIterator(ProductList list){
		this.products=list.getList();
		cursor1=0;
		cursor2=products.size()-1;
	}
	
	@Override
	public void next() {
		// TODO Auto-generated method stub
		if(cursor1<products.size()){
			cursor1++;
		}
	}

	@Override
	public boolean isLast() {
		// TODO Auto-generated method stub
		return (cursor1==products.size());
	}

	@Override
	public void previous() {
		// TODO Auto-generated method stub
		if(cursor2>-1){
			cursor2--;
		}
	}

	@Override
	public boolean isFirst() {
		// TODO Auto-generated method stub
		return (cursor2==-1);
	}

	@Override
	public Object getNextItem() {
		// TODO Auto-generated method stub
		return products.get(cursor1);
	}

	@Override
	public Object getPreviousItem() {
		// TODO Auto-generated method stub
		return products.get(cursor2);
	}

}
