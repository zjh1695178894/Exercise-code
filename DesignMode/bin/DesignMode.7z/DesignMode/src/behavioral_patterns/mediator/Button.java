package behavioral_patterns.mediator;

public class Button extends Component{

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

}
