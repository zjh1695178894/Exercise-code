package behavioral_patterns.mediator;

public class Client {
	public static void main(String args[]){
		ConcreteMediator mediator=new ConcreteMediator();
		
		Button addButton=new Button();
		List list=new List();
		TextBox userNameTextBox=new TextBox();
		ComboBox cb=new ComboBox();
		
		addButton.setMediator(mediator);
		list.setMediator(mediator);
		userNameTextBox.setMediator(mediator);
		cb.setMediator(mediator);
		
		mediator.addButton=addButton;
		mediator.list=list;
		mediator.cb=cb;
		mediator.userNameTextBox=userNameTextBox;
				
		addButton.changed();
		list.changed();
	}
}
