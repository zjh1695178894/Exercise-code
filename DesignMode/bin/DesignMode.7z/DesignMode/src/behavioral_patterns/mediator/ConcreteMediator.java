package behavioral_patterns.mediator;

public class ConcreteMediator extends Mediator{
	public Button addButton;
	public List list;
	public TextBox userNameTextBox;
	public ComboBox cb;
	
	@Override
	public void componentChanged(Component c) {
		// TODO Auto-generated method stub
		if(c==addButton){
			System.out.println("==�������Ӱ�ť==");
			list.update();
			cb.update();
			userNameTextBox.update();
		}else if(c==list){
			System.out.println("==���б���ѡ��ͻ�==");
			cb.select();
			userNameTextBox.update();
		}else if(c==cb){
			System.out.println("==����Ͽ���ѡ��ͻ�==");
			cb.select();
			userNameTextBox.update();
		}
	}

}
