package behavioral_patterns.mediator;

public abstract class Mediator {
	public abstract void componentChanged(Component component);
}
