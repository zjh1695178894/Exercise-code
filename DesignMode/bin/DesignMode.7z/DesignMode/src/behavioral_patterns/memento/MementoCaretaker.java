package behavioral_patterns.memento;

import java.util.*;

public class MementoCaretaker {
	private List<ChessmanMemento> mementoList=new ArrayList<>();
	public ChessmanMemento getMemento(int i) {
		return mementoList.get(i);
	}

	public void setMemento(ChessmanMemento memento) {
		mementoList.add(memento);
	}
	
}
