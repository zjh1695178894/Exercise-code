package behavioral_patterns.observer;

import java.util.ArrayList;

public abstract class AllyControllerCenter {
	protected String allyName;
	protected ArrayList<Observer> players=new ArrayList<>();
	public String getAllyName() {
		return allyName;
	}
	public void setAllyName(String allyName) {
		this.allyName = allyName;
	}
	public void join(Observer ob){
		System.out.println(ob.getName()+"����"+this.allyName+"ս�ӣ�");
		players.add(ob);
	}
	public void quit(Observer ob){
		System.out.println(ob.getName()+"�˳�"+this.allyName+"ս�ӣ�");
		players.remove(ob);
	}
	public abstract void notifyObserver(String name);
}
