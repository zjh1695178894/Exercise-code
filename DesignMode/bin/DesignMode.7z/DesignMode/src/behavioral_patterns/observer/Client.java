package behavioral_patterns.observer;

public class Client {
	public static void main(String args[]){
		AllyControllerCenter acc=new ConcreteAllyControllerCenter("��ӹȺ��");
		
		Observer player1,player2,player3,player4;
		player1=new Players("���");
		acc.join(player1);
		player2=new Players("�����");
		acc.join(player2);
		player3=new Players("���޼�");
		acc.join(player3);
		player4=new Players("����");
		acc.join(player4);
		
		player4.beAttacked(acc);
	}
}
