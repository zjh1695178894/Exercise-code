package behavioral_patterns.observer;

public class ConcreteAllyControllerCenter extends AllyControllerCenter {
	public ConcreteAllyControllerCenter(String name){
		System.out.println(name+"ս���齨�ɹ���");
		System.out.println("=========================================================");
		this.allyName=name;
	}
	@Override
	public void notifyObserver(String name) {
		System.out.println(this.allyName+"ս�ӽ���֪ͨ������"+name+"���ܵ��˹���!");
		for(Observer ob:players){
			if(!((Observer)ob).getName().equalsIgnoreCase(name)){
				((Observer)ob).help();
			}
		}
	}

}
