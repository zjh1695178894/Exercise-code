package behavioral_patterns.observer;

public class Players implements Observer {
	private String name;
	
	public Players(String name){
		this.setName(name);
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}

	@Override
	public void help() {
		// TODO Auto-generated method stub
		System.out.println("���ס��"+name+"����������");
	}

	@Override
	public void beAttacked(AllyControllerCenter acc) {
		// TODO Auto-generated method stub
		System.out.println(this.name+"��������");
		acc.notifyObserver(name);
	}

}
