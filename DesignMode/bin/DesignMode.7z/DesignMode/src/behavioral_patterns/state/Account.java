package behavioral_patterns.state;

public class Account {
	private AccountState state;
	private String owner;
	private double balance;
	public Account(String owner,double balance){
		this.owner=owner;
		this.balance=balance;
		this.state=new NormalState(this);
		System.out.println(this.owner+"开户，初始金额"+balance);
		System.out.println("======================================================");
	}
	public void setState(AccountState state) {
		this.state = state;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void deposit(double ammount){
		System.out.println(this.owner+"存款"+ammount);
		state.deposit(ammount);
		System.out.println("现在余额为"+this.balance);
		System.out.println("现在账户状态为"+this.state.getClass().getName());
		System.out.println("======================================================");
	}
	public void withdraw(double ammount){
		System.out.println(this.owner+"取款"+ammount);
		state.withdraw(ammount);
		System.out.println("现在余额为"+this.balance);
		System.out.println("现在账户状态为"+this.state.getClass().getName());
		System.out.println("======================================================");
	}
	public void compute(){
		state.compute();
	}
}
