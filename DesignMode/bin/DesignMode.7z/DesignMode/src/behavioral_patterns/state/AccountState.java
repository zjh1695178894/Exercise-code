package behavioral_patterns.state;

public abstract class AccountState {
	protected Account acc;
	public abstract void deposit(double ammount);
	public abstract void withdraw(double ammount);
	public abstract void compute();
	public abstract void stateCheck();
}
