package behavioral_patterns.state;

public class NormalState extends AccountState {
	public NormalState(Account acc){
		this.acc=acc;
	}
	public NormalState(AccountState state){
		this.acc=state.acc;
	}
	@Override
	public void deposit(double ammount) {
		// TODO Auto-generated method stub
		acc.setBalance(acc.getBalance()+ammount);
		stateCheck();
	}

	@Override
	public void withdraw(double ammount) {
		// TODO Auto-generated method stub
		acc.setBalance(acc.getBalance()-ammount);
		stateCheck();
	}

	@Override
	public void compute() {
		// TODO Auto-generated method stub
		System.out.println("正常状态，无需支付利息");
	}

	@Override
	public void stateCheck() {
		// TODO Auto-generated method stub
		if(acc.getBalance()>-2000&&acc.getBalance()<0){
			acc.setState(new OverState(this));
		}
		else if(acc.getBalance()==-2000){
			acc.setState(new RestrictedState(this));
		}
		else if(acc.getBalance()<-2000){
			System.out.println("操作受限");
		}
	}

}
