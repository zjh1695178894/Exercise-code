package behavioral_patterns.state;

public class OverState extends AccountState {
	public OverState(AccountState state){
		this.acc=state.acc;
	}
	@Override
	public void deposit(double ammount) {
		// TODO Auto-generated method stub
		acc.setBalance(acc.getBalance()+ammount);
		stateCheck();
	}

	@Override
	public void withdraw(double ammount) {
		// TODO Auto-generated method stub
		acc.setBalance(acc.getBalance()-ammount);
		stateCheck();
	}

	@Override
	public void compute() {
		// TODO Auto-generated method stub
		System.out.println("计算利息");
	}

	@Override
	public void stateCheck() {
		// TODO Auto-generated method stub
		if(acc.getBalance()>0){
			acc.setState(new NormalState(this));
		}
		else if(acc.getBalance()==-2000){
			acc.setState(new RestrictedState(this));
		}
		else if(acc.getBalance()<-2000){
			System.out.println("操作受限");
		}
	}

}
