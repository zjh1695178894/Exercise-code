package behavioral_patterns.state.screen;

public class Client {
	public static void main(String args[]){
		Screen s=new Screen();
		s.onClick();
		s.onClick();
		s.onClick();
	}
}
