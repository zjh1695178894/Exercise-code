package behavioral_patterns.state.screen;

public class LargerState extends ScreenState {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("二倍大小");
	}

}
