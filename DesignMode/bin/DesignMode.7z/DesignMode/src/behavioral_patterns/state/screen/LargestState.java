package behavioral_patterns.state.screen;

public class LargestState extends ScreenState {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("四倍大小");
	}

}
