package behavioral_patterns.state.screen;

public class NormalState extends ScreenState {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("正常大小");
	}

}
