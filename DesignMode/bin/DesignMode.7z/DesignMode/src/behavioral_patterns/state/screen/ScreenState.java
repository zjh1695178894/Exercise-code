package behavioral_patterns.state.screen;

public abstract class ScreenState {
	public abstract void display();
}
