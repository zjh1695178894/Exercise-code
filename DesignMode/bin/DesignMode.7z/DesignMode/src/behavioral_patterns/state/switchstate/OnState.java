package behavioral_patterns.state.switchstate;

public class OnState extends SwitchState {

	@Override
	public void on(Switch s) {
		// TODO Auto-generated method stub
		System.out.println("已经打开");
	}

	@Override
	public void off(Switch s) {
		// TODO Auto-generated method stub
		System.out.println("关闭！");
		s.setState(Switch.getState("off"));
	}

}
