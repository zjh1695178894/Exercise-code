package behavioral_patterns.state.switchstate;

public class Switch {
	private String name;
	private static SwitchState currentState,onState,offState;
	public Switch(String name){
		this.name=name;
		currentState=new OnState();
		onState=new OnState();
		offState=new OffState();
	
	}
	public void setState(SwitchState state){
		currentState=state;
	}
	public static SwitchState getState(String type){
		if(type.equalsIgnoreCase("on")){
			return onState;
		}else{
			return offState;
		}
	}
	public void on(){
		System.out.print(name);
		currentState.on(this);
	}
	public void off(){
		System.out.print(name);
		currentState.off(this);
	}
}
