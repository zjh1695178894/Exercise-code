package behavioral_patterns.strategy;

public class Client {
	public static void main(String args[]){
		MovieTicket mt=new MovieTicket();
		double originPrice=60;
		double currentPrice=0;
		
		mt.setPrice(originPrice);
		System.out.println("原价为："+originPrice);
		System.out.println("========================");
		
		Discount discount=(Discount) XMLUtil.getBean();
		mt.setDiscount(discount);
		currentPrice= mt.calculate();
		System.out.println("折后价为："+currentPrice);
	}
}
