package behavioral_patterns.strategy;

public interface Discount {
	public double calculate(double price);
}
