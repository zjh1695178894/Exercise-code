package behavioral_patterns.strategy;

public class MovieTicket {
	private double price;
	private Discount discount;
	public void setPrice(double price) {
		this.price = price;
	}
	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
	public double calculate(){
		return this.discount.calculate(price);
	}
}
