package behavioral_patterns.strategy;

public class StudentDiscount implements Discount {
	private final double DISCOUNT=0.8;
	@Override
	public double calculate(double price) {
		// TODO Auto-generated method stub
		System.out.println("学生票八折：");
		return price*DISCOUNT;
	}

}
