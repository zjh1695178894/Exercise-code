package behavioral_patterns.strategy;

public class VipDiscount implements Discount {
	private final double DISCOUNT=0.5;
	@Override
	public double calculate(double price) {
		// TODO Auto-generated method stub
		System.out.println("VIP票五折：");
		System.out.println("增加VIP积分");
		return price*DISCOUNT;
	}

}
