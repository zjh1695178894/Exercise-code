package behavioral_patterns.strategy;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLUtil {
	public static Object getBean(){
		try{
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File("src//behavioral_patterns//strategy//config.xml"));
		
		NodeList nodeList = document.getElementsByTagName("classname");
		Node node= nodeList.item(0).getFirstChild();
		String value = node.getNodeValue();
		
		Class name = Class.forName(value);
		Object object = name.newInstance();
		return object;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
}
