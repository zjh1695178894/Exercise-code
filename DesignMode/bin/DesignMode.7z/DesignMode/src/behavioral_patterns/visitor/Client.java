package behavioral_patterns.visitor;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployList list=new EmployList();
		Employment e1=new FulltimeEmployment("张三",3200.00,45);
		Employment e2=new FulltimeEmployment("李四",3200.00,60);
		Employment e3=new FulltimeEmployment("王五",3200.00,35);
		Employment e4=new FulltimeEmployment("赵六",3200.00,15);
		Employment e5=new parttimeEmployment("小明",60.00,45);
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		list.add(e5);
		
		Department fa=new FADepartment();
		Department hr=new HRDepartment();
		
		list.accept(hr);
		list.accept(fa);
	}

}
