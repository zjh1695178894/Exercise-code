package behavioral_patterns.visitor;

public interface Department {
	public abstract void visit(FulltimeEmployment e);
	public abstract void visit(parttimeEmployment e);
}
