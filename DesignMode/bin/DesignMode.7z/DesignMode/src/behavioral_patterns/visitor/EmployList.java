package behavioral_patterns.visitor;

import java.util.*;

public class EmployList {
	private List<Employment> list=new ArrayList<Employment>();
	public void add(Employment e){
		list.add(e);
	}
	public void accept(Department handle){
		for(Object obj:list){
			((Employment)obj).accept(handle);
		}
	}
}
