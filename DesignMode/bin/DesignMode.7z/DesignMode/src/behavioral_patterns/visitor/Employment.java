package behavioral_patterns.visitor;

public interface Employment {
	public void accept(Department handle);
}
