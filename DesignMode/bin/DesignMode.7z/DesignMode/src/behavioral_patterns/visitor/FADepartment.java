package behavioral_patterns.visitor;

public class FADepartment implements Department {
	 
	@Override
	public void visit(FulltimeEmployment e) {
		// TODO Auto-generated method stub
		int worktime = e.getWorkTime();
		double weeklywage = e.getWeeklyWage();
		if(worktime>40){
			weeklywage=weeklywage+(worktime-40)*100;
		}
		else if(worktime<40){
			weeklywage=weeklywage-(40-worktime)*80;
			if(weeklywage<0){
				weeklywage=0;
			}
		}
		System.out.println("正式员工"+e.getName()+"实际工资"+weeklywage);
	}

	@Override
	public void visit(parttimeEmployment e) {
		// TODO Auto-generated method stub
		int worktime = e.getWorkTime();
		double weeklywage = e.getWeeklyWage();
		System.out.println("正式员工"+e.getName()+"实际工资"+weeklywage*worktime);
	}

}
