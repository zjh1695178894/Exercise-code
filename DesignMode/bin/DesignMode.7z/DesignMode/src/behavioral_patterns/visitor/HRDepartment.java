package behavioral_patterns.visitor;

public class HRDepartment implements Department {

	@Override
	public void visit(FulltimeEmployment e) {
		// TODO Auto-generated method stub
		int worktime=e.getWorkTime();
		if(worktime>40){
			System.out.println("正式员工"+e.getName()+"实际工作时间"+worktime+"加班时间"+(worktime-40));
		}else if(worktime<40){
			System.out.println("正式员工"+e.getName()+"实际工作时间"+worktime+"请假时间"+(40-worktime));
		}else{
			System.out.println("正式员工"+e.getName()+"实际工作时间"+worktime);
		}
	}

	@Override
	public void visit(parttimeEmployment e) {
		// TODO Auto-generated method stub
		int worktime=e.getWorkTime();
		System.out.println("临时员工"+e.getName()+"实际工作时间"+worktime);
	}

}
