package creational_patterns.builder;

public class Actor {
	private String type;
	private String sex;
	private String face;
	private String custome;
	private String hairstyle;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getFace() {
		return face;
	}
	public void setFace(String face) {
		this.face = face;
	}
	public String getCustome() {
		return custome;
	}
	public void setCustome(String custome) {
		this.custome = custome;
	}
	public String getHairstyle() {
		return hairstyle;
	}
	public void setHairstyle(String hairstyle) {
		this.hairstyle = hairstyle;
	}
	
}
