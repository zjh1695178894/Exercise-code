package creational_patterns.builder;

public class ActorController {
	public Actor construct(ActorBuilder ab){
		ab.buildType();
		ab.buildSex();
		ab.buildFace();
		ab.buildCustom();
		ab.buildHairstyle();
		Actor actor = ab.createActor();
		return actor;
	}
}
