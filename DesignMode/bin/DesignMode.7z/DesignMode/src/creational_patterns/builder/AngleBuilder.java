package creational_patterns.builder;

public class AngleBuilder extends ActorBuilder{

	@Override
	public void buildType() {
		actor.setType("angle");
		
	}

	@Override
	public void buildSex() {
		actor.setSex("female");
		
	}

	@Override
	public void buildFace() {
		actor.setFace("nice");
	}

	@Override
	public void buildCustom() {
		actor.setCustome("white");
	}

	@Override
	public void buildHairstyle() {
		actor.setHairstyle("golden");
	}

}
