package creational_patterns.builder;

public class Client {

	public static void main(String[] args) {
		ActorBuilder ab=(ActorBuilder)XMLUtil.getBean();
		ActorController ac=new ActorController();
		Actor actor = ac.construct(ab);
		
		System.out.println(actor.getType()+"�����");
		System.out.println("�Ա�:"+actor.getSex());
		System.out.println("����:"+actor.getFace());
		System.out.println("��װ:"+actor.getCustome());
		System.out.println("����:"+actor.getHairstyle());

	}

}
