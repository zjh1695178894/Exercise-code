package creational_patterns.builder;

public class DevilBuilder extends ActorBuilder{

	@Override
	public void buildType() {
		actor.setType("devil");
		
	}

	@Override
	public void buildSex() {
		actor.setSex("female");
		
	}

	@Override
	public void buildFace() {
		actor.setFace("ugly");
	}

	@Override
	public void buildCustom() {
		actor.setCustome("black");
	}

	@Override
	public void buildHairstyle() {
		actor.setHairstyle("gray");
	}

}
