package creational_patterns.builder;

public class HeroBuilder extends ActorBuilder{

	@Override
	public void buildType() {
		actor.setType("hero");
		
	}

	@Override
	public void buildSex() {
		actor.setSex("male");
		
	}

	@Override
	public void buildFace() {
		actor.setFace("handsome");
	}

	@Override
	public void buildCustom() {
		actor.setCustome("smart");
	}

	@Override
	public void buildHairstyle() {
		actor.setHairstyle("cool");
	}

}
