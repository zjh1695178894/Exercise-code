package creational_patterns.factoryMethod;

public class DataBaseLogger implements Logger {

	@Override
	public void writeLog() {
		System.out.println("���ݿ���־��¼");
		}

}
