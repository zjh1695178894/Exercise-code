package creational_patterns.factoryMethod;

public class FileLogger implements Logger {

	@Override
	public void writeLog() {
		System.out.println("�ļ���־��¼");
		}

}
