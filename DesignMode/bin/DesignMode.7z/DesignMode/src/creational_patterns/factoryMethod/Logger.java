package creational_patterns.factoryMethod;

public interface Logger {
	public void writeLog();
}
