package creational_patterns.factoryMethod;

public interface LoggerFactory {
	public Logger createLogger();
}
