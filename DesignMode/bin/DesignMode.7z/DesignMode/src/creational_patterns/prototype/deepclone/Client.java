package creational_patterns.prototype.deepclone;

public class Client {

	public static void main(String[] args) {
		WeeklyLog log_preview=new WeeklyLog();
		WeeklyLog log_new=new WeeklyLog();
		Attachment at=new Attachment();
		log_preview.setAttachment(at);
		try{
			log_new=log_preview.deepClone();
		}catch(Exception e){
			System.out.println("��¡ʧ��!");
		}
		System.out.println("�ܱ��Ƿ���ͬ:"+(log_preview==log_new));
		System.out.println("�����Ƿ���ͬ:"+(log_preview.getAttachment()==log_new.getAttachment()));
	}

}
