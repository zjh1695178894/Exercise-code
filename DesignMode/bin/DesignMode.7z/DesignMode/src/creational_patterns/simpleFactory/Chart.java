package creational_patterns.simpleFactory;

public interface Chart {
	public void display();
}
