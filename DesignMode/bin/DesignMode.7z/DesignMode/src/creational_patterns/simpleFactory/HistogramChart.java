package creational_patterns.simpleFactory;

public class HistogramChart implements Chart {
	public HistogramChart(){
		System.out.println("������״ͼ");
	}
	@Override
	public void display() {
		System.out.println("��ʾ��״ͼ");
	}

}
