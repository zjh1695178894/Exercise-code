package creational_patterns.simpleFactory;

public class PieChart implements Chart {
	public PieChart(){
		System.out.println("������״ͼ");
	}
	@Override
	public void display() {
		System.out.println("��ʾ��״ͼ");
	}

}
