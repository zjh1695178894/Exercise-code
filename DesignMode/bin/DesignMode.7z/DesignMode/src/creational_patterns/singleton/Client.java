package creational_patterns.singleton;

public class Client {

	public static void main(String[] args) {
		LoaderBalancer b1,b2,b3,b4;
		b1=LoaderBalancer.getLoaderBalancer();
		b2=LoaderBalancer.getLoaderBalancer();
		b3=LoaderBalancer.getLoaderBalancer();
		b4=LoaderBalancer.getLoaderBalancer();
		System.out.println("���������ؾ����һ���ԣ�"+(b1==b2&&b2==b3&&b3==b4));
		
		b1.addServer("server1");
		b2.addServer("server2");
		b3.addServer("server3");
		b4.addServer("server4");
		for(int i=0;i<10;i++){
			String getserver = b1.getserver();
			System.out.println("�ַ�������������"+getserver);
		}
	}

}
