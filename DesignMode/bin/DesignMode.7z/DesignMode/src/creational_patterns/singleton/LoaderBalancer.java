package creational_patterns.singleton;

import java.util.ArrayList;
import java.util.Random;

public class LoaderBalancer {
	private static LoaderBalancer instance;
	private ArrayList list=null;
	private LoaderBalancer(){
		list=new ArrayList();
	}
	
	public static LoaderBalancer getLoaderBalancer(){
		if(instance==null){
			instance=new LoaderBalancer();
		}
		return instance;
	}
	
	public void addServer(String server){
		list.add(server);
	}
	public void removeServer(String server){
		list.remove(server);
	}
	public String getserver(){
		Random random=new Random();
		int i = random.nextInt(list.size());
		return (String) list.get(i);
	}
}
