package structural_patterns.adapter;

public abstract class CarController {
	public void move(){
		System.out.println("�����ƶ�");
	}
	public abstract void phonate();
	public abstract void twinkle();
}
