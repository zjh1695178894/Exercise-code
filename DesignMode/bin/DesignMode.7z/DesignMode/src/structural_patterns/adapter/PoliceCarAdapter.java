package structural_patterns.adapter;

public class PoliceCarAdapter extends CarController{
	public PoliceLamp lamp;
	public PoliceSound sound;
	public PoliceCarAdapter(){
		lamp=new PoliceLamp();
		sound=new PoliceSound();
	}

	@Override
	public void phonate() {
		sound.alarmSound();
	}

	@Override
	public void twinkle() {
		lamp.alarmLamp();
	}
	
}
