package structural_patterns.adapter;

public class PoliceLamp {
	public void alarmLamp(){
		System.out.println("������˸");
	}
}
