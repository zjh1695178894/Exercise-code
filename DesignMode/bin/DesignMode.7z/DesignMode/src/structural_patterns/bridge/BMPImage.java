package structural_patterns.bridge;

public class BMPImage extends Image{

	@Override
	public void parseFile(String name) {
		Martrix m=new Martrix();
		imp.dopaint(m);
		System.out.println(name+",��ʽΪBMP");
	}

}
