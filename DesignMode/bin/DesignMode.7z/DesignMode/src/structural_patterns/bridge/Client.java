package structural_patterns.bridge;

public class Client {

	public static void main(String[] args) {
		ImageImpl imp=new LinuxImpl();
		Image image=new JPGImage();
		image.setImp(imp);
		image.parseFile("̫ƽʢ��");
	}

}
