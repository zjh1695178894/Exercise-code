package structural_patterns.bridge;

public interface ImageImpl {
	public void dopaint(Martrix m);
}
