package structural_patterns.bridge;

public class LinuxImpl implements ImageImpl {

	@Override
	public void dopaint(Martrix m) {
		System.out.println("��Linux����ʾͼ��");
	}

}
