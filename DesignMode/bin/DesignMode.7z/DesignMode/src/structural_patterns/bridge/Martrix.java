package structural_patterns.bridge;

public class Martrix {

}
