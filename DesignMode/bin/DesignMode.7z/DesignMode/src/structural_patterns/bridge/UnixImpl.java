package structural_patterns.bridge;

public class UnixImpl implements ImageImpl {

	@Override
	public void dopaint(Martrix m) {
		System.out.println("��Unix����ʾͼ��");
	}

}
