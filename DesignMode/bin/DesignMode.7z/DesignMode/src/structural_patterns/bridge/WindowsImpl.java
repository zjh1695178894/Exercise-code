package structural_patterns.bridge;

public class WindowsImpl implements ImageImpl {

	@Override
	public void dopaint(Martrix m) {
		System.out.println("��Windows����ʾͼ��");
	}

}
