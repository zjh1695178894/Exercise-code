package structural_patterns.decorator;

public class BlackBorderDecorator extends ComponentDecorator{

	public BlackBorderDecorator(Component component) {
		super(component);
	}
	
	public void display(){
		super.display();
		this.setBlackBorder();
	}

	private void setBlackBorder() {
		System.out.println("Ϊ�������Ӻ�ɫ�߿�");
	}

}
