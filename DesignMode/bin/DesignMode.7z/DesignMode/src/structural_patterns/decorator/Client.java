package structural_patterns.decorator;

public class Client {

	public static void main(String[] args) {
		Component component=new Window();
		Component componentSB=new ScrollBarDecorator(component);
		componentSB.display();
		
		Component componentBB=new BlackBorderDecorator(componentSB);
		componentBB.display();
	}

}
