package structural_patterns.decorator;

public abstract class Component {
	public abstract void display();
}
