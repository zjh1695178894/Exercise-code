package structural_patterns.decorator;

public class ListBox extends Component{

	@Override
	public void display() {
		System.out.println("��ʾ�б���");
	}

}
