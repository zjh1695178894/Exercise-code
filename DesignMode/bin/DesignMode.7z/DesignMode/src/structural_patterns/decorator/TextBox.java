package structural_patterns.decorator;

public class TextBox extends Component{

	@Override
	public void display() {
		System.out.println("��ʾ�ı���");
	}

}
