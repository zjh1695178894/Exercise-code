package structural_patterns.decorator;

public class Window extends Component{

	@Override
	public void display() {
		System.out.println("��ʾ����");
	}

}
