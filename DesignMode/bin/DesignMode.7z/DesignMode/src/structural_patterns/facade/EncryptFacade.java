package structural_patterns.facade;

public class EncryptFacade {
	private FileReader rd;
	private CipherMachine cm;
	private FileWriter wt;
	
	public EncryptFacade(){
		rd=new FileReader();
		cm=new CipherMachine();
		wt=new FileWriter();
	}
	public void FileEncrypt(String fileNameSrc,String fileNameDes){
		String plainStr = rd.read(fileNameSrc);
		String encryptStr = cm.encrypt(plainStr);
		wt.write(encryptStr, fileNameDes);
	}
}
