package structural_patterns.flyweight;

public class BlackIgoChessman extends IgoChessman{

	@Override
	public String getColor() {
		return "��ɫ";
	}

}
