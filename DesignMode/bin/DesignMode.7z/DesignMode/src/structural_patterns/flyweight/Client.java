package structural_patterns.flyweight;

public class Client {
	public static void main(String args[]){
		IgoChessman b1,b2,b3,w1,w2;
		IgoChessmanFactory factory=IgoChessmanFactory.getInstance();
		
		b1=factory.getIgoChessman("b");
		b2=factory.getIgoChessman("b");
		b3=factory.getIgoChessman("b");
		
		w1=factory.getIgoChessman("w");
		w2=factory.getIgoChessman("w");
		
		b1.display(new Coordinates(1,2));
		b2.display(new Coordinates(3,4));
		b3.display(new Coordinates(7,5));
		w1.display(new Coordinates(16,5));
		w2.display(new Coordinates(7,33));
	}
}
