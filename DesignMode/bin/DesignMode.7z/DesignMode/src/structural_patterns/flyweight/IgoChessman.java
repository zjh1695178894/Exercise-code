package structural_patterns.flyweight;

public abstract class IgoChessman {
	public  abstract String getColor();
	public void display(Coordinates coord){
		System.out.println("Χ�����ɫ:"+this.getColor()+";���ӵ�λ��:"+coord.getX()
		+","+coord.getY());
	}
}
