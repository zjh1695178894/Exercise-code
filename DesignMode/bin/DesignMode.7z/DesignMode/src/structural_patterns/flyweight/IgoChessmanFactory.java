package structural_patterns.flyweight;

import java.util.Hashtable;

public class IgoChessmanFactory {
	//ʹ�õ���ģʽ
	private static IgoChessmanFactory instance=new IgoChessmanFactory();
	private static Hashtable ht;
	private IgoChessmanFactory(){
		ht=new Hashtable();
		IgoChessman black=new BlackIgoChessman();
		IgoChessman white=new WhiteIgoChessman();
		ht.put("b", black);
		ht.put("w", white);
	}
	public static IgoChessmanFactory getInstance(){
		return instance;
	}
	public static IgoChessman getIgoChessman(String color){
		return (IgoChessman) ht.get(color);
	}
}
