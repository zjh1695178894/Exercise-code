package structural_patterns.flyweight;

public class WhiteIgoChessman extends IgoChessman{

	@Override
	public String getColor() {
		return "��ɫ";
	}

}
