package structural_patterns.proxy.common;

public class Client {

	public static void main(String[] args) {
		Searcher searcher=(Searcher) XMLUtil.getBean();
		//ProxySearcher searcher=new ProxySearcher();
		searcher.doSearcher("���", "��Ů�ľ�");
	}

}
