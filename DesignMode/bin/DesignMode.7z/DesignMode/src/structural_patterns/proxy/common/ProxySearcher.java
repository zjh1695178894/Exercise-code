package structural_patterns.proxy.common;

public class ProxySearcher implements Searcher {

	private RealSearcher realSearcher=new RealSearcher();
	private Logger logger;
	private AccessValidator validator;
	
	public boolean validate(String userId){
		validator=new AccessValidator();
		return validator.validate(userId);
	}
	public void log(String userId){
		logger=new Logger();
		logger.log(userId);
	}
	
	@Override
	public void doSearcher(String userId, String keyword) {
		if(this.validate(userId)){
			realSearcher.doSearcher(userId, keyword);
			this.log(userId);
		}else{
		System.out.println("��ѯ��Ϣʧ�ܣ�");
		}
	}

}
