package structural_patterns.proxy.common;

public class RealSearcher implements Searcher {

	@Override
	public void doSearcher(String userId, String keyword) {
		System.out.println("�û�'"+userId+"'ʹ�ùؼ���'"+keyword+"'��ѯ��Ϣ");
	}

}
