package structural_patterns.proxy.common;

public interface Searcher {
	public void doSearcher(String userId,String keyword);
}
