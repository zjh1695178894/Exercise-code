package structural_patterns.proxy.common;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

public class XMLUtil {
	public static Object getBean(){
		try{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = factory.newDocumentBuilder();
			Document document = documentBuilder.parse(new File("src//proxy//common//config.xml"));
			
			String value = document.getElementsByTagName("className").item(0).getFirstChild().getNodeValue();
			
			Class name = Class.forName(value);
			Object object = name.newInstance();
			return object;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
}
