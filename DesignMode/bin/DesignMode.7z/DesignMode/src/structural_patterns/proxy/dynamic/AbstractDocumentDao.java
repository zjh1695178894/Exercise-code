package structural_patterns.proxy.dynamic;

public interface AbstractDocumentDao {
	public boolean deleteDocumentById(String documentId);
}
