package structural_patterns.proxy.dynamic;

public interface AbstractUserDao {
	public boolean findUserbyId(String userId);
}
