package structural_patterns.proxy.dynamic;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
//��δ������,14�п�ָ���쳣
public class Client {

	public static void main(String[] args) {
		AbstractUserDao userDao=new Userdao();
		InvocationHandler handler=new DaoLogHandler(userDao);
		AbstractUserDao proxy=(AbstractUserDao) Proxy.newProxyInstance(handler.getClass().getClassLoader(),
				userDao.getClass().getInterfaces(),handler);
		System.out.println(proxy.getClass().getName());
		proxy.findUserbyId("��");
	}

}
