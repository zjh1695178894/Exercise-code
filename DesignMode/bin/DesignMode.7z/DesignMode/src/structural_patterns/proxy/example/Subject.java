package structural_patterns.proxy.example;

public interface Subject {
	public void rent();
    
    public void hello(String str);
}
