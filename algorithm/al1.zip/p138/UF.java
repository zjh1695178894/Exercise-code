package p138;

import java.util.Random;

public class UF {
	private int[] id;
	private int count;
	public UF(int n){
		count=n;
		id=new int[n];
		for(int k=0;k<n;k++){
			id[k]=k;
		}
	}
	public int count(){
		return count;
	}
	public boolean connected(int p,int q){
		return find(p)==find(q);
	}
	/*quick-find算法
	public int find(int p){
		return id[p];
	}
	public void union(int p,int q){
		int pid=find(p);
		int qid=find(q);
		if(pid==qid){
			return;
		}else{
			for(int i=0;i<count;i++){
				if(id[i]==pid){
					id[i]=qid;
				}
			}
		}
	}
	*/
	//quick-union算法
	public int find(int p){
		if(p!=id[p]){
			p=id[p];
		}
		return p;
	}
	public void union(int p,int q){
		int proot=find(p);
		int qroot=find(q);
		if(qroot==proot){
			return;
		}else{
			id[proot]=qroot;
			count--;
		}
	}
}
