package p153;

public class Example {
	/*//选择排序
	public static void sort(Comparable[] a){
		int n=a.length;
		for(int i=0;i<n;i++){
			int min=i;
			for(int j=i+1;j<n;j++){
				if(less(a[i],a[j])){
					min=j;
				}
				exch(a,i,min);
			}
		}
	}*/
	/*//插入排序
	public static void sort(Comparable[] a){
		int n=a.length;
		for(int i=0;i<n;i++){
			for(int j=i;j>0&&less(a[j],a[j-1]);j--){
				exch(a,j,j-1);
			}
		}
	}*/
	//希尔排序
	public static void sort(Comparable[] a){
		int n=a.length;
		int h=1;
		while(h<n/3){
			h=h*3+1;
		}
		while(h>=1){
			for(int i=h;i<n;i++){
				for(int j=i;j>h&&less(a[j],a[j-h]);j-=h){
					exch(a,j-h,j);
				}
			}
			h/=3;
		}
	}
	public static boolean less(Comparable a,Comparable b){
		//compareTo:前者比后者大，返回1；相等返回0；小于返回-1
		//此处判断a是否小于b，是的话方法返回一个true
		return a.compareTo(b)<0;
	}
	public static void exch(Comparable[] a,int i,int j){
		Comparable t=a[i];
		a[i]=a[j];
		a[j]=t;
	}
	public static boolean isSorted(Comparable[] a){
		for(int i=1;i<a.length;i++){
			if(less(a[i],a[i-1])){
				return false;
			}
		}
		return true;
	}
}