package p170;
//自顶向下的归并排序
public class MergeUp {
	private static Comparable[] aux;
	public static void sort(Comparable[] a){
		int n=a.length;
		aux=new Comparable[n];
		for(int sz=1;sz<n;sz=2*sz){
			for(int lo=0;lo<n-sz;lo=lo+2*sz){
				merge(a,lo,lo+sz-1,Math.min(lo+2*sz-1,n-1));
			}
		}
	}
	//通用的归并方法
	public static void merge(Comparable[] a,int lo,int mid,int hi){
		int i=lo;
		int j=mid+1;
		for(int k=lo;k<hi;k++){
			aux[k]=a[k];
		}
		for(int k=lo;k<hi;k++){
			//如果左侧的数据全部安置完，就以此安置右边的数据
			//如果右边的数据安置完，安置左边
			//如果右侧的目前的索引表示的值大于左侧，就安置左侧并将相应的索引+1
			if(i>mid){
				a[k]=aux[i++];
			}else if(j>hi){
				a[k]=aux[j++];
			}else if(less(a[i],a[j])){
				a[k]=aux[i++];
			}else{
				a[k]=aux[j++];
			}
		}
	}
	public static boolean less(Comparable a,Comparable b){
		//compareTo:前者比后者大，返回1；相等返回0；小于返回-1
		//此处判断a是否小于b，是的话方法返回一个true
		return a.compareTo(b)<0;
	}
}
