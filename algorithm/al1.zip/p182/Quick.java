package p182;

public class Quick {
	public static void sort(Comparable[] a){
		sort(a,0,a.length-1);
	}
	private static void sort(Comparable[] a, int lo, int hi) {
		// TODO Auto-generated method stub
		if(lo>=hi)
			return;
		int j=partition(a,lo,hi);
		sort(a,lo,j);
		sort(a,j+1,hi);
	}
	//三项切分的快速排序
	public static void sortModify(Comparable[] a,int lo,int hi){
		if(lo>=hi)
			return;
		int lt=lo;
		int i=lo+1;
		int gt=hi;
		Comparable x=a[lo];
		while(i<=hi){
			int cmp=a[i].compareTo(x);
			if(cmp<0){
				exch(a,lt++,i++);
			}else if(cmp>0){
				exch(a,i,gt--);
			}else{
				i++;
			}
		}
		sort(a,lo,lt-1);
		sort(a,gt+1,hi);
		}
	private static int partition(Comparable[] a, int lo, int hi) {
		// TODO Auto-generated method stub
		int i=lo;int j=hi+1;
		Comparable index=a[lo];
		while(true){
			while(less(a[++i],index)) if(i==hi) break;
			while(less(index,a[--j])) if(j==lo) break;
			if(i>=j) break;
			exch(a,i,j);
		}
		exch(a,lo,j);
		return j;
		
	}
	public static boolean less(Comparable a,Comparable b){
		//compareTo:前者比后者大，返回1；相等返回0；小于返回-1
		//此处判断a是否小于b，是的话方法返回一个true
		return a.compareTo(b)<0;
	}
	public static void exch(Comparable[] a,int i,int j){
		Comparable t=a[i];
		a[i]=a[j];
		a[j]=t;
	}
}
