package p202;

public class MaxPQ<key extends Comparable<key>> {
	private key[] pq;
	private int N=0;
	public MaxPQ(int count){
		pq=(key[]) new Comparable[count+1];
	}
	public boolean isEmpty(){
		return N==0;
	}
	public int size(){
		return N;
	}
	public void insert(key v){
		pq[++N]=v;
		swim(N);
	}
	public key deleteMax(){
		key max=pq[1];
		exct(1,N--);
		pq[N+1]=null;
		sink(1);
		return max;
	}
	private boolean less(int i,int j){
		return pq[i].compareTo(pq[j])<0;
	}
	private void exct(int i,int j){
		key k=pq[i];
		pq[i]=pq[j];
		pq[j]=k;
	}
	//如果这个节点比他的父节点大，就把他与她的父节点交换位置
	private void swim(int k){
		while(k>1&&less(k/2,k)){
			exct(k/2,k);
			k=k/2;
		}
	}
	//如果这个节点比他的子节点小，就把他与两个子节点中更大的那个交换位置
	private void sink(int k){
		while(2*k<=N){
		int j=2*k;
		if(j<N&&less(j,j+1))
			j++;
			if(!less(k,j))
				break;
			exct(k,j);
			k=j;
		}
	}
}
