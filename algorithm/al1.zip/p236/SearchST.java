package p236;
//基于无序链表对于符号表的操作
public class SearchST<Key,Value>{
	private Node first;
	private class Node{
		Key key;
		Value value;
		Node next;
		public Node(Key k,Value v,Node next){
			this.key=k;
			this.value=v;
			this.next=next;
		}
	}
	//根据键获取值
	public Value get(Key key){
		for(Node x=first;x!=null;x=x.next){
			if(key.equals(x.key)){
				return x.value;
			}
		}
		return null;
	}
	//更新值，如果没有找到这个键，就在链表头部新增一个
	public void put(Key key,Value value){
		for(Node x=first;x!=null;x=x.next){
			if(key.equals(x.key)){
				x.value=value;
				return;
			}
		}
		first=new Node(key,value,first);
	}
	//获取整个链表的长度
	public int size(){
		if(first==null){
			return 0;
		}
		int count=1;
		Node x=first;
		while(x.next!=null){
			x=x.next;
			count++;
		}
		return count;
	}
	//删除某个值
	public void delete(Key k){
		if(k.equals(first.key)){
			first=first.next;
		}
		for(Node x=first;x!=null;x=x.next){
			if(k.equals(x.next.key)){
				x.next=x.next.next;
			}
		}
		return;
	}
}
