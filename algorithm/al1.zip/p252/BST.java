package p252;

import java.util.LinkedList;
import java.util.Queue;

//基于二叉查找树的符号表
public class BST<Key extends Comparable<Key>,Value>{
	private class Node{
		private Key key;
		private Value value;
		private Node left,right;
		private int N;
		public Node(Key key, Value value, int n) {
			this.key = key;
			this.value = value;
			N = n;
		}
	}
	private Node root;
	public int size(){
		return size(root);
	}
	private int size(Node root) {
		if(root==null)
		return 0;
		else return root.N;
	}
	//从根节点开始查找某个节点(键)
	private Value get(Key key){
		return get(root,key);
	}
	private Value get(Node node, Key key) {
		if(node==null)
			return null;
		int cmp=key.compareTo(node.key);
		if(cmp>0){
			return get(node.right,key);
		}else if(cmp<0){
			return get(node.left,key);
		}else{
			return node.value;
		}
	}
	//查找key，找到则更新它的值，否则就创建一个节点
	private void put(Key key,Value v){
		root=put(root,key,v);
	}
	private Node put(Node n, Key k, Value v) {
		if(n==null)
		return new Node(k,v,1);
		int cmp=k.compareTo(n.key);
		if(cmp<0){
			n.left=put(n.left,k,v);
		}else if(cmp>0){
			n.right=put(n.right,k,v);
		}else{
			n.value=v;
			n.N=size(n.left)+size(n.right)+1;
		}
		return n;
	}
	//查找最小值
	public Key min(){
		return min(root).key;
	}
	public Node min(Node n){
		if(n==null)
			return n;
		return min(n.left);
	}
	//查找最大值
	public Key max(){
		return min(root).key;
	}
	public Node max(Node n){
		if(n==null)
			return n;
		return max(n.right);
	}
	//小于等于key的最大键
	public Key floor(Key k){
		Node x=floor(root,k);
		if(x==null)
			return null;
		return x.key;
	}
	public Node floor(Node n,Key k){
		if(n==null)
			return null;
		int cmp=k.compareTo(n.key);
		if(cmp==0){
			return n;
		}else if(cmp<0){
			return floor(n.left,k);
		}
		//如果根据上面的判断部分找到了小于等于key的子树集合，就继续沿这个子树的右子树寻找这个子树的最大值
		//也就是小于等于key的最大值
		Node x=floor(n.right,k);
		if(x==null)
			return n;
		return x;
	}
	//查找排名为k的键（即二叉树中有k个节点小于它）
	public Key select(int k){
		return select(root,k).key;
	}
	public Node select(Node n,int k){
		if(n==null)
			return null;
		//获取这个节点的左子树的N
		int t=size(n.left);
		if(t>k){
			return select(n.left,k);
		}else if(t<k){
			return select(n.right,k-t-1);
		}else{
			return n;
		}
	}
	//返回给定键的排名
	public int rank(Key k){
		return rank(root,k);
	}
	public int rank(Node n,Key k){
		if(n==null)
			return 0;
		int cmp=k.compareTo(n.key);
		if(cmp<0){
			return rank(n.left,k);
		}else if(cmp>0){
			return rank(n.right,k)+1+size(n.left);
		}else{
			return size(n.left);
		}
	}
	//删除最小的键对应的节点
	public void deleteMin(){
		root=deleteMin(root);
	}
	public Node deleteMin(Node n){
		if(n.left==null)
			return n.right;
		n.left=deleteMin(n.left);
		n.N=size(n.left)+size(n.right)+1;
		return n;
	}
	//删除二叉查找树中存在的一个键值对
	public void delete(Key k){
		root=delete(root,k);
	}
	public Node delete(Node n,Key k){
		if(n==null)
			return null;
		int cmp=k.compareTo(n.key);
		if(cmp<0){
			n.left=delete(n.left,k);
		}else if(cmp>0){
			n.right=delete(n.right,k);
		}else{
			if(n.right==null)
				return n.left;
			if(n.left==null)
				return n.right;
			//如果这个即将被删除的节点有两个子节点的话
			//保存要被删除的节点
			Node t=n;
			//n指向该节点下右子树的最小节点（替代它原本位置的节点）
			n=min(n.right);
			//将这个最小节点的左连接（原本为空）指向被删除节点的左子树
			n.left=t.left;
			//将这个最小节点的有链接（原本指向一个大于它的二叉查找树）指向删除后依然大于
			//该节点的子二叉查找树
			n.right=deleteMin(t.right);
		}
		n.N=size(n.left)+size(n.right)+1;
		return n;
	}
	//指定范围lo到hi之间的内的查找（通过队列实现）
	public Iterable<Key> keys(){
		return keys(min(),max());
	}
	public Iterable<Key> keys(Key lo,Key hi){
		Queue<Key> q=new LinkedList<>();
		keys(root,q,lo,hi);
		return q;
	}
	public void keys(Node n,Queue<Key> q,Key lo,Key hi){
		if(n==null)
			return;
		int cmplo=lo.compareTo(n.key);
		int cmphi=hi.compareTo(n.key);
		if(cmplo<0){
			keys(n.left,q,lo,hi);
		}else if(cmplo<=0&&cmphi>=0){
			q.add(n.key);
		}else if(cmphi>0){
			keys(n.right,q,lo,hi);
		}
	}
}
