package p281;


//红黑树
public class RedBlackBST<Key extends Comparable<Key>,Value>{
	private static final boolean RED=true;
	private static final boolean BLACK=false;
	private Node root;
	private class Node{
		Key key;
		Value value;
		Node left,right;
		int N;
		boolean color;
		public Node(Key key, Value value, int n, boolean color) {
			this.key = key;
			this.value = value;
			N = n;
			this.color = color;
		}
	}
	private boolean isRed(Node n){
		if(n==null)
			return false;
		return n.color==RED;
	}
	private int size(Node n) {
		if(n==null)
		return 0;
		else return n.N;
	}
	//左旋转，红色右链接变为红色左链接
	private Node rotateLeft(Node n){
		Node x=n.right;
		n.right=x.left;
		x.left=n;
		x.color=n.color;
		n.color=RED;
		x.N=n.N;
		n.N=1+size(n.left)+size(n.right);
		return x;
	}
	//右旋转
	private Node rotateRight(Node n){
		Node x=n.left;
		n.left=x.right;
		x.right=n;
		x.color=n.color;
		n.color=RED;
		x.N=n.N;
		n.N=1+size(n.left)+size(n.right);
		return x;
	}
	//颜色转换，当一个节点的两个链接都是红色时，将它自己的父链接变为红色，把两条子链接变为黑色
	private void flipColor(Node n){
		n.color=BLACK;
		n.left.color=RED;
		n.right.color=RED;
	}
	//查找key，找到则更新它的值，没有的话创建它
	public void put(Key k,Value v){
		root=put(root,k,v);
		root.color=RED;
	}
	private Node put(Node n, Key k, Value v) {
		if(n==null)
			return new Node(k,v,1,RED);
		int cmp=k.compareTo(n.key);
		if(cmp<0){
			return put(n.left,k,v);
		}else if(cmp>0){
			return put(n.right,k,v);
		}else{
			n.value=v;
		}
		
		if(isRed(n.right)&&!isRed(n.left)){
			n=rotateLeft(n);
		}else if(isRed(n.left)&&isRed(n.left.left)){
			n=rotateRight(n);
		}else if(isRed(n.left)&&isRed(n.right)){
			flipColor(n);
		}
		n.N=1+size(n.left)+size(n.right);
		return n;
	}
	//删除操作
	public void delete(Key k){
		if(!isRed(root.left)&&!isRed(root.right))
			root.color=RED;
		root=delete(root,k);
	}
	private Node balance(Node n){
		if(isRed(n.right))
			n=rotateLeft(n);
		if(isRed(n.right)&&!isRed(n.left)){
			n=rotateLeft(n);
		}else if(isRed(n.left)&&isRed(n.left.left)){
			n=rotateRight(n);
		}else if(isRed(n.left)&&isRed(n.right)){
			flipColor(n);
		}
		n.N=1+size(n.left)+size(n.right);
		return n;
	}
}
